package com.bn

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
